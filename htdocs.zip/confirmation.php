<?php
include 'config.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

$orderId = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
$stmt = $db->prepare("SELECT orders.*, items.name as item_name FROM orders JOIN items ON orders.item_id = items.id WHERE orders.id = ?");
$stmt->execute([$orderId]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    die("Order not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation - MpratamaShop</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background: #1a2a44;
            color: #fff;
            margin: 0;
            padding: 0;
        }
        header {
            background: #2a9d8f;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5rem;
            font-weight: 700;
        }
        nav a {
            color: #fff;
            margin-left: 1rem;
            text-decoration: none;
        }
        nav a:hover {
            text-decoration: underline;
        }
        .confirmation-section {
            max-width: 600px;
            margin: 2rem auto;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">MpratamaShop</div>
        <nav>
            <a href="index.php">Home</a>
            <a href="shop.php">Shop</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <section class="confirmation-section">
        <h2>Order Confirmation</h2>
        <p>Thank you for your order! Your order ID is <strong><?php echo htmlspecialchars($order['id']); ?></strong>.</p>
        <p>Item: <?php echo htmlspecialchars($order['item_name']); ?></p>
        <p>Name: <?php echo htmlspecialchars($order['name']); ?></p>
        <p>Email: <?php echo htmlspecialchars($order['email']); ?></p>
        <p>Payment Method: <?php echo htmlspecialchars($order['payment_method']); ?></p>
        <p>Status: <?php echo htmlspecialchars($order['status']); ?></p>
        <a href="shop.php" class="buy-btn" style="background: #2a9d8f; color: #fff; padding: 0.8rem 1.5rem; border: none; border-radius: 10px; text-decoration: none; display: inline-block;">Back to Shop</a>
    </section>

    <footer>
        <p>© 2025 MpratamaShop. All rights reserved.</p>
    </footer>
</body>
</html>