<?php
include 'config.php';

if (isset($_GET['item'])) {
    $itemName = urldecode($_GET['item']);
    $stmt = $db->prepare("SELECT * FROM items WHERE name = ?");
    $stmt->execute([$itemName]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop - MpratamaShop</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .currency-icon {
            width: 30px;
            height: 30px;
            max-width: 30px;
            max-height: 30px;
            object-fit: contain;
            vertical-align: middle;
        }
        .currency-symbol {
            vertical-align: middle;
        }
        .currency-symbol.rupiah, .currency-symbol.dollar {
            color: #00FF00;
            font-size: 0.9rem;
        }
        .item-details {
            max-width: 600px;
            margin: 2rem auto;
            background: rgba(255, 255, 255, 0.1);
            padding: 2rem;
            border-radius: 15px;
            text-align: center;
            position: relative;
        }
        .item-details img {
            width: 250px;
            height: 250px;
            object-fit: cover;
            margin-bottom: 1rem;
            border-radius: 10px;
        }
        .price-container {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            justify-content: center;
            margin: 1rem 0;
            align-items: center;
        }
        .price-container.item-detail-price {
            margin-top: 1.5rem;
        }
        .price-item {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            font-size: 1rem;
            color: #fff;
            background: rgba(231, 111, 81, 0.7);
            padding: 0.3rem 0.7rem;
            border-radius: 10px;
            min-height: 35px;
            max-height: 40px;
            line-height: 1;
        }
        .price-item.item-detail-price-item .currency-icon {
            margin-top: 2px;
        }
        .buy-btn {
            background: #2a9d8f;
            color: #fff;
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .buy-btn:hover {
            background: #264653;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">MpratamaShop</div>
        <nav>
            <a href="index.php">Home</a>
            <a href="shop.php">Shop</a>
            <a href="login.php">Login</a>
            <?php if (isLoggedIn()): ?>
                <a href="logout.php">Logout</a>
            <?php endif; ?>
        </nav>
    </header>

    <section class="shop-section">
        <?php if (isset($item) && $item): ?>
            <div class="item-details">
                <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                <p><?php echo htmlspecialchars($item['description']); ?></p>
                <div class="price-container item-detail-price">
                    <?php if ($item['price_gold'] > 0): ?>
                        <div class="price-item item-detail-price-item">
                            <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/e4826e7fae29e5e2d2394149617c9c1268148de1/img2/gold.svg" alt="Gold" class="currency-icon">
                            <span class="currency-symbol"><?php echo $item['price_gold']; ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if ($item['price_rupiah'] > 0): ?>
                        <div class="price-item item-detail-price-item">
                            <span class="currency-symbol rupiah">Rp</span>
                            <span class="currency-symbol"><?php echo number_format($item['price_rupiah']); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if ($item['price_dollar'] > 0): ?>
                        <div class="price-item item-detail-price-item">
                            <span class="currency-symbol dollar">$</span>
                            <span class="currency-symbol"><?php echo $item['price_dollar']; ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if ($item['price_starshards'] > 0): ?>
                        <div class="price-item item-detail-price-item">
                            <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/e4826e7fae29e5e2d2394149617c9c1268148de1/img2/Starshards.svg" alt="Starshards" class="currency-icon">
                            <span class="currency-symbol"><?php echo $item['price_starshards']; ?></span>
                        </div>
                    <?php endif; ?>
                </div>
                <a href="shop.php" class="buy-btn">Back to Shop</a>
                <?php if (isLoggedIn()): ?>
                    <a href="checkout.php?item_id=<?php echo $item['id']; ?>" class="buy-btn">Buy Now</a>
                <?php else: ?>
                    <a href="login.php" class="buy-btn">Login to Buy</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <h2 class="shop-title">Shop</h2>
            <div class="shop-stall">
                <?php
                $itemsStmt = $db->query("SELECT * FROM items");
                $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
                if (count($items) > 0) {
                    foreach ($items as $item) {
                        echo "<div class='shop-item'>";
                        echo "<img src='" . htmlspecialchars($item['image']) . "' alt='" . htmlspecialchars($item['name']) . "'>";
                        echo "<h3>" . htmlspecialchars($item['name']) . "</h3>";
                        echo "<div class='price-container'>";
                        if ($item['price_gold'] > 0) {
                            echo "<div class='price-item'><img src='https://raw.githubusercontent.com/mpratamastore/mpstoretest/e4826e7fae29e5e2d2394149617c9c1268148de1/img2/gold.svg' alt='Gold' class='currency-icon'><span class='currency-symbol'>" . $item['price_gold'] . "</span></div>";
                        }
                        if ($item['price_rupiah'] > 0) {
                            echo "<div class='price-item'><span class='currency-symbol rupiah'>Rp</span><span class='currency-symbol'>" . number_format($item['price_rupiah']) . "</span></div>";
                        }
                        if ($item['price_dollar'] > 0) {
                            echo "<div class='price-item'><span class='currency-symbol dollar'>$</span><span class='currency-symbol'>" . $item['price_dollar'] . "</span></div>";
                        }
                        if ($item['price_starshards'] > 0) {
                            echo "<div class='price-item'><img src='https://raw.githubusercontent.com/mpratamastore/mpstoretest/e4826e7fae29e5e2d2394149617c9c1268148de1/img2/Starshards.svg' alt='Starshards' class='currency-icon'><span class='currency-symbol'>" . $item['price_starshards'] . "</span></div>";
                        }
                        echo "</div>";
                        echo "<a href='shop.php?item=" . urlencode($item['name']) . "' class='buy-btn'>View</a>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No items available in the shop.</p>";
                }
                ?>
            </div>
        <?php endif; ?>
    </section>

    <footer>
        <p>© 2025 MpratamaShop. All rights reserved.</p>
    </footer>
</body>
</html>