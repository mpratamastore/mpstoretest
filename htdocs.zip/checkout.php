<?php
include 'config.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

$itemId = isset($_GET['item_id']) ? (int)$_GET['item_id'] : 0;
$stmt = $db->prepare("SELECT * FROM items WHERE id = ?");
$stmt->execute([$itemId]);
$item = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$item) {
    die("Item not found.");
}

// Handle order submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $userId = $_SESSION['user_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $paymentMethod = $_POST['payment_method'];

    $stmt = $db->prepare("INSERT INTO orders (user_id, item_id, name, email, payment_method, status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$userId, $itemId, $name, $email, $paymentMethod, 'Pending']);
    header("Location: confirmation.php?order_id=" . $db->lastInsertId());
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - MpratamaShop</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background: #1a2a44;
            color: #fff;
            margin: 0;
            padding: 0;
        }
        header {
            background: #2a9d8f;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5rem;
            font-weight: 700;
        }
        nav a {
            color: #fff;
            margin-left: 1rem;
            text-decoration: none;
        }
        nav a:hover {
            text-decoration: underline;
        }
        .checkout-section {
            max-width: 600px;
            margin: 2rem auto;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            text-align: center;
        }
        .form-group {
            margin-bottom: 1rem;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
        }
        .form-group input, .form-group select {
            padding: 0.5rem;
            width: 100%;
            border: none;
            border-radius: 5px;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
        }
        .form-group button {
            padding: 0.8rem 1.5rem;
            background: #2a9d8f;
            border: none;
            border-radius: 10px;
            color: #fff;
            cursor: pointer;
        }
        .form-group button:hover {
            background: #264653;
        }
        .price-container {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            justify-content: center;
            margin: 1rem 0;
            align-items: center;
        }
        .price-item {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            font-size: 1rem;
            color: #fff;
            background: rgba(231, 111, 81, 0.7);
            padding: 0.3rem 0.7rem;
            border-radius: 10px;
            min-height: 35px;
            max-height: 40px;
            line-height: 1;
        }
        .currency-icon {
            width: 30px;
            height: 30px;
            max-width: 30px;
            max-height: 30px;
            object-fit: contain;
            vertical-align: middle;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">MpratamaShop</div>
        <nav>
            <a href="index.php">Home</a>
            <a href="shop.php">Shop</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <section class="checkout-section">
        <h2>Checkout</h2>
        <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" style="width: 200px; height: 200px; object-fit: cover; margin-bottom: 1rem; border-radius: 10px;">
        <h3><?php echo htmlspecialchars($item['name']); ?></h3>
        <p><?php echo htmlspecialchars($item['description']); ?></p>
        <div class="price-container">
            <?php if ($item['price_gold'] > 0): ?>
                <div class="price-item">
                    <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/e4826e7fae29e5e2d2394149617c9c1268148de1/img2/gold.svg" alt="Gold" class="currency-icon">
                    <span><?php echo $item['price_gold']; ?></span>
                </div>
            <?php endif; ?>
            <?php if ($item['price_rupiah'] > 0): ?>
                <div class="price-item">
                    <span style="color: #00FF00;">Rp</span>
                    <span><?php echo number_format($item['price_rupiah']); ?></span>
                </div>
            <?php endif; ?>
            <?php if ($item['price_dollar'] > 0): ?>
                <div class="price-item">
                    <span style="color: #00FF00;">$</span>
                    <span><?php echo $item['price_dollar']; ?></span>
                </div>
            <?php endif; ?>
            <?php if ($item['price_starshards'] > 0): ?>
                <div class="price-item">
                    <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/e4826e7fae29e5e2d2394149617c9c1268148de1/img2/Starshards.svg" alt="Starshards" class="currency-icon">
                    <span><?php echo $item['price_starshards']; ?></span>
                </div>
            <?php endif; ?>
        </div>

        <form method="POST" class="form-group">
            <label for="name">Full Name:</label>
            <input type="text" name="name" id="name" required>
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>
            <label for="payment_method">Payment Method:</label>
            <select name="payment_method" id="payment_method" required>
                <option value="Credit Card">Credit Card</option>
                <option value="PayPal">PayPal</option>
                <option value="Bank Transfer">Bank Transfer</option>
            </select>
            <button type="submit" name="place_order">Place Order</button>
        </form>
        <a href="shop.php" class="buy-btn">Back to Shop</a>
    </section>

    <footer>
        <p>© 2025 MpratamaShop. All rights reserved.</p>
    </footer>
</body>
</html>