<?php
session_start();

// Database connection
$dbPath = 'C:/xampp/htdocs/mpratamashop.db';
error_log("Attempting to use database path: $dbPath");

$baseDir = dirname($dbPath);
if (!is_dir($baseDir) || !is_writable($baseDir)) {
    die("Directory is not writable or does not exist: $baseDir");
}

// Initialize database connection
$db = null;
if (file_exists($dbPath)) {
    $db = new PDO("sqlite:$dbPath");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->query("SELECT 1");
} else {
    $db = new PDO("sqlite:$dbPath");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}

// Check if the 'users' table exists
$result = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='users'");
$usersTableExists = $result->fetchColumn();

if (!$usersTableExists) {
    $db->exec("CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user'
    )");

    $db->exec("CREATE TABLE items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        image TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        category TEXT NOT NULL,
        price_gold INTEGER,
        price_rupiah INTEGER,
        price_dollar INTEGER,
        price_starshards INTEGER
    )");

    $db->exec("CREATE TABLE orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        item_id INTEGER,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        payment_method TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (item_id) REFERENCES items(id)
    )");

    $result = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='users'");
    if ($result->fetchColumn() === false) {
        throw new PDOException("Failed to create users table.");
    }

    $adminPassword = password_hash('Anonymous263', PASSWORD_DEFAULT);
    $stmt = $db->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->execute(['mpragans', 'admin@mpratamashop.com', $adminPassword, 'admin']);
}

$db->query("SELECT 1 FROM users LIMIT 1");

// Authentication functions
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getUserRole($db) {
    if (isLoggedIn()) {
        $stmt = $db->prepare("SELECT role FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetchColumn() ?: 'user';
    }
    return 'guest';
}

function login($db, $username, $password) {
    $stmt = $db->prepare("SELECT id, password, role FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        return true;
    }
    return false;
}

function register($db, $username, $email, $password) {
    // Check for existing email
    $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetchColumn() > 0) {
        return ["success" => false, "message" => "Email already exists."];
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $db->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    try {
        $stmt->execute([$username, $email, $hashedPassword]);
        return ["success" => true, "message" => "Registration successful."];
    } catch (PDOException $e) {
        return ["success" => false, "message" => "Registration failed: " . $e->getMessage()];
    }
}
?>