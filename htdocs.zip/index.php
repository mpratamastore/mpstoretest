<?php
include 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home - MpratamaShop</title>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <div class="logo">MpratamaShop</div>
    <nav>
      <a href="#home">Home</a>
      <a href="shop.php">Shop</a>
      <a href="#about">About</a>
      <a href="login.php">Login</a>
    </nav>
  </header>

  <section class="hero" id="home">
    <div class="hero-text">
      <h1>Welcome to MpratamaShop</h1>
      <p>Discover magical items and treasures for your adventures!</p>
      <a href="#about" class="btn">Learn More</a>
    </div>
    <div class="hero-images">
      <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/refs/heads/main/img/house.png" alt="House" class="house">
      <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/refs/heads/main/img/crystal1.png" alt="Crystal1" class="crystal1">
      <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/refs/heads/main/img/cystal2.png" alt="Crystal2" class="crystal2">
      <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/refs/heads/main/img/mini%20crystal1.png" alt="Mini1" class="mini1">
      <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/refs/heads/main/img/minicrystal2.png" alt="Mini2" class="mini2">
      <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/refs/heads/main/img/mini%20crystal3.png" alt="Mini3" class="mini3">
      <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/refs/heads/main/img/rock.png" alt="Rock" class="rock">
      <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/refs/heads/main/img/star.png" alt="Star" class="star">
    </div>
  </section>

  <section class="about-section" id="about">
    <h2>About Us</h2>
    <p>We are a magical shop offering a wide range of enchanted items for adventurers, collectors, and dreamers. Explore our collection and find the perfect treasure!</p>
    <div class="about-features">
      <div class="feature-card">
        <h3>Quality Items</h3>
        <p>Hand-picked magical treasures.</p>
      </div>
      <div class="feature-card">
        <h3>Secure Checkout</h3>
        <p>Safe and easy transactions.</p>
      </div>
      <div class="feature-card">
        <h3>Fast Delivery</h3>
        <p>Get your items quickly.</p>
      </div>
    </div>
  </section>

  <footer>
    <p>© 2025 MpratamaShop. All rights reserved.</p>
  </footer>

  <script src="script.js"></script>
</body>
</html>