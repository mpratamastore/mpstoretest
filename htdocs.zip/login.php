<?php
include 'config.php';

$registrationMessage = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $result = register($db, $username, $email, $password);
    $registrationMessage = $result['message'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    if (login($db, $username, $password)) {
        if (getUserRole($db) === 'admin') {
            header("Location: dashboard.php");
        } else {
            header("Location: dashboard.php");
        }
        exit();
    } else {
        $loginError = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - MpratamaShop</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background: #1a2a44;
            color: #fff;
            margin: 0;
            padding: 0;
        }
        header {
            background: #2a9d8f;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5rem;
            font-weight: 700;
        }
        nav a {
            color: #fff;
            margin-left: 1rem;
            text-decoration: none;
        }
        nav a:hover {
            text-decoration: underline;
        }
        .login-section {
            max-width: 400px;
            margin: 2rem auto;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
        }
        .form-group input {
            padding: 0.5rem;
            width: 100%;
            border: none;
            border-radius: 5px;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
        }
        .form-group button {
            padding: 0.5rem 1rem;
            background: #2a9d8f;
            border: none;
            border-radius: 5px;
            color: #fff;
            cursor: pointer;
        }
        .form-group button:hover {
            background: #264653;
        }
        .error {
            color: #e76f51;
            margin-bottom: 1rem;
        }
        .success {
            color: #2a9d8f;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">MpratamaShop</div>
        <nav>
            <a href="index.php">Home</a>
            <a href="shop.php">Shop</a>
        </nav>
    </header>

    <section class="login-section">
        <h2>Login</h2>
        <?php if (isset($loginError)): ?>
            <div class="error"><?php echo $loginError; ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" name="username" id="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" required>
            </div>
            <div class="form-group">
                <button type="submit" name="login">Login</button>
            </div>
        </form>

        <h2>Register</h2>
        <?php if ($registrationMessage): ?>
            <div class="<?php echo strpos($registrationMessage, 'successful') !== false ? 'success' : 'error'; ?>">
                <?php echo htmlspecialchars($registrationMessage); ?>
            </div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label for="reg_username">Username:</label>
                <input type="text" name="username" id="reg_username" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div class="form-group">
                <label for="reg_password">Password:</label>
                <input type="password" name="password" id="reg_password" required>
            </div>
            <div class="form-group">
                <button type="submit" name="register">Register</button>
            </div>
        </form>
    </section>

    <footer>
        <p>© 2025 MpratamaShop. All rights reserved.</p>
    </footer>
</body>
</html>