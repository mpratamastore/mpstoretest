<?php
$db = new PDO("sqlite:" . __DIR__ . '/mpratamashop.db');
echo "Connection successful!";
?>