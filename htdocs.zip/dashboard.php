<?php
include 'config.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

$userRole = getUserRole($db);
$userId = $_SESSION['user_id'];

// Handle order status update (admin only)
if ($userRole === 'admin' && isset($_POST['update_status'])) {
    $orderId = $_POST['order_id'];
    $newStatus = $_POST['new_status'];

    try {
        $stmt = $db->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$newStatus, $orderId]);
        $successMessage = "Order status updated successfully!";
    } catch (PDOException $e) {
        $errorMessage = "Failed to update order status: " . $e->getMessage();
    }
}

// Handle item creation (admin only)
if ($userRole === 'admin' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_item'])) {
    $image = $_POST['item_image'];
    $name = $_POST['item_name'];
    $description = $_POST['item_description'];
    $category = $_POST['item_category'];
    $price_gold = (int)$_POST['price_gold'];
    $price_rupiah = (int)$_POST['price_rupiah'];
    $price_dollar = (int)$_POST['price_dollar'];
    $price_starshards = (int)$_POST['price_starshards'];

    $stmt = $db->prepare("INSERT INTO items (image, name, description, category, price_gold, price_rupiah, price_dollar, price_starshards) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$image, $name, $description, $category, $price_gold, $price_rupiah, $price_dollar, $price_starshards]);
}

// Handle item deletion (admin only)
if ($userRole === 'admin' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_item'])) {
    $itemId = (int)$_POST['item_id'];
    $stmt = $db->prepare("DELETE FROM items WHERE id = ?");
    $stmt->execute([$itemId]);
}

// Handle new order (for all users)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $itemId = (int)$_POST['item_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $paymentMethod = $_POST['payment_method'];

    $stmt = $db->prepare("INSERT INTO orders (user_id, item_id, name, email, payment_method, status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$userId, $itemId, $name, $email, $paymentMethod, 'Pending']);
    $successMessage = "Order placed successfully!";
}

// Fetch items and orders
$itemsStmt = $db->query("SELECT * FROM items");
$items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch orders based on user role
if ($userRole === 'admin') {
    $ordersStmt = $db->query("SELECT orders.*, items.name as item_name FROM orders JOIN items ON orders.item_id = items.id");
} else {
    $ordersStmt = $db->prepare("SELECT orders.*, items.name as item_name FROM orders JOIN items ON orders.item_id = items.id WHERE orders.user_id = ?");
    $ordersStmt->execute([$userId]);
}
$orders = $ordersStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - MpratamaShop</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background: #1a2a44;
            color: #fff;
            margin: 0;
            padding: 0;
        }
        header {
            background: #2a9d8f;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5rem;
            font-weight: 700;
        }
        nav a {
            color: #fff;
            margin-left: 1rem;
            text-decoration: none;
        }
        nav a:hover {
            text-decoration: underline;
        }
        .dashboard-section {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
        }
        h2 {
            color: #e76f51;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
        }
        .form-group input, .form-group select {
            padding: 0.5rem;
            width: 100%;
            max-width: 300px;
            border: none;
            border-radius: 5px;
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
        }
        .form-group button {
            padding: 0.5rem 1rem;
            background: #2a9d8f;
            border: none;
            border-radius: 5px;
            color: #fff;
            cursor: pointer;
        }
        .form-group button:hover {
            background: #264653;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        th, td {
            padding: 0.8rem;
            text-align: left;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }
        th {
            background: rgba(231, 111, 81, 0.7);
        }
        .status-form {
            display: inline-flex;
            gap: 0.5rem;
            align-items: center;
        }
        .status-select {
            padding: 0.3rem;
            border-radius: 5px;
            border: none;
            background: #2a9d8f;
            color: #fff;
        }
        .update-btn {
            padding: 0.3rem 0.8rem;
            border: none;
            border-radius: 5px;
            background: #e76f51;
            color: #fff;
            cursor: pointer;
        }
        .update-btn:hover {
            background: #264653;
        }
        .message {
            margin: 1rem 0;
            padding: 0.8rem;
            border-radius: 5px;
        }
        .success {
            background: rgba(42, 157, 143, 0.3);
        }
        .error {
            background: rgba(231, 111, 81, 0.3);
        }
        .shop-item {
            background: rgba(255, 255, 255, 0.1);
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 10px;
            text-align: center;
        }
        .shop-item img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 10px;
        }
        .price-container {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            justify-content: center;
            margin: 1rem 0;
        }
        .price-item {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            font-size: 1rem;
            color: #fff;
            background: rgba(231, 111, 81, 0.7);
            padding: 0.3rem 0.7rem;
            border-radius: 10px;
        }
        .currency-icon {
            width: 20px;
            height: 20px;
            max-width: 20px;
            max-height: 20px;
            object-fit: contain;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">MpratamaShop Dashboard</div>
        <nav>
            <a href="index.php">Home</a>
            <a href="shop.php">Shop</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <section class="dashboard-section">
        <?php if ($userRole === 'admin'): ?>
            <h2>Manage Items</h2>
            <form method="POST" class="form-group">
                <label for="item_image">Image URL:</label>
                <input type="text" name="item_image" id="item_image" required>
                <label for="item_name">Item Name:</label>
                <input type="text" name="item_name" id="item_name" required>
                <label for="item_description">Description:</label>
                <input type="text" name="item_description" id="item_description" required>
                <label for="item_category">Category:</label>
                <input type="text" name="item_category" id="item_category" required>
                <label for="price_gold">Price in Gold:</label>
                <input type="number" name="price_gold" id="price_gold" min="0">
                <label for="price_rupiah">Price in Rupiah:</label>
                <input type="number" name="price_rupiah" id="price_rupiah" min="0">
                <label for="price_dollar">Price in Dollar:</label>
                <input type="number" name="price_dollar" id="price_dollar" min="0">
                <label for="price_starshards">Price in Starshards:</label>
                <input type="number" name="price_starshards" id="price_starshards" min="0">
                <button type="submit" name="create_item">Create Item</button>
            </form>

            <h3>Existing Items</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['id']); ?></td>
                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                            <td><?php echo htmlspecialchars($item['category']); ?></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                                    <button type="submit" name="delete_item">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <h2>Manage Orders</h2>
        <?php if (isset($successMessage)): ?>
            <div class="message success"><?php echo $successMessage; ?></div>
        <?php endif; ?>
        <?php if (isset($errorMessage)): ?>
            <div class="message error"><?php echo $errorMessage; ?></div>
        <?php endif; ?>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Item Name</th>
                    <th>Status</th>
                    <?php if ($userRole === 'admin'): ?>
                        <th>Action</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($order['id']); ?></td>
                        <td><?php echo htmlspecialchars($order['item_name']); ?></td>
                        <td><?php echo htmlspecialchars($order['status']); ?></td>
                        <?php if ($userRole === 'admin'): ?>
                            <td>
                                <form method="POST" class="status-form">
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <select name="new_status" class="status-select">
                                        <option value="Pending" <?php echo $order['status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="Processing" <?php echo $order['status'] == 'Processing' ? 'selected' : ''; ?>>Processing</option>
                                        <option value="Shipped" <?php echo $order['status'] == 'Shipped' ? 'selected' : ''; ?>>Shipped</option>
                                        <option value="Delivered" <?php echo $order['status'] == 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
                                        <option value="Cancelled" <?php echo $order['status'] == 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                    </select>
                                    <button type="submit" name="update_status" class="update-btn">Update</button>
                                </form>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h2>Order New Service</h2>
        <div class="shop-stall">
            <?php foreach ($items as $item): ?>
                <div class="shop-item">
                    <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                    <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                    <p><?php echo htmlspecialchars($item['description']); ?></p>
                    <div class="price-container">
                        <?php if ($item['price_gold'] > 0): ?>
                            <div class="price-item">
                                <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/e4826e7fae29e5e2d2394149617c9c1268148de1/img2/gold.svg" alt="Gold" class="currency-icon">
                                <span><?php echo $item['price_gold']; ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if ($item['price_rupiah'] > 0): ?>
                            <div class="price-item">
                                <span style="color: #00FF00;">Rp</span>
                                <span><?php echo number_format($item['price_rupiah']); ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if ($item['price_dollar'] > 0): ?>
                            <div class="price-item">
                                <span style="color: #00FF00;">$</span>
                                <span><?php echo $item['price_dollar']; ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if ($item['price_starshards'] > 0): ?>
                            <div class="price-item">
                                <img src="https://raw.githubusercontent.com/mpratamastore/mpstoretest/e4826e7fae29e5e2d2394149617c9c1268148de1/img2/Starshards.svg" alt="Starshards" class="currency-icon">
                                <span><?php echo $item['price_starshards']; ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                    <form method="POST" class="form-group">
                        <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                        <label for="name_<?php echo $item['id']; ?>">Full Name:</label>
                        <input type="text" name="name" id="name_<?php echo $item['id']; ?>" required>
                        <label for="email_<?php echo $item['id']; ?>">Email:</label>
                        <input type="email" name="email" id="email_<?php echo $item['id']; ?>" required>
                        <label for="payment_method_<?php echo $item['id']; ?>">Payment Method:</label>
                        <select name="payment_method" id="payment_method_<?php echo $item['id']; ?>" required>
                            <option value="Credit Card">Credit Card</option>
                            <option value="PayPal">PayPal</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                        </select>
                        <button type="submit" name="place_order">Place Order</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <footer>
        <p>© 2025 MpratamaShop. All rights reserved.</p>
    </footer>
</body>
</html>